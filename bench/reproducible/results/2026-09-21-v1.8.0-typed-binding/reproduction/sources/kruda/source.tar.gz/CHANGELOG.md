# Changelog

All notable changes to Kruda are documented in this file.
Format based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/).

## [1.8.0] — 2026-09-21

### Added

- Generated binding is now usable from external applications (experimental).
  The generator moved from `internal/bindgen` to the runnable
  `github.com/go-kruda/kruda/cmd/bindgen`, emits a `GeneratedPlan` per input
  with a descriptor-based validator factory, and no longer rejects validated
  inputs outside the framework. Select the plan on any typed route with the
  new `WithGeneratedPlan` route option. Stale shapes, custom rule overrides,
  and unsupported rules all fail closed to the generic parser and validation.
  See "Generated Binding" in the handlers guide.

## [1.7.2] — 2026-09-03

### Security

- TLS now fails closed when a custom transport cannot consume Kruda's TLS
  configuration. A transport used with `WithTLS` must implement
  `transport.TLSServer`; Kruda no longer risks starting that transport without
  the requested certificate and key.
- Hardened Wing connection ownership across takeover, pending reads, queued
  writes and static sendfile. Responses queued before `Takeover` remain ordered,
  Linux reads suppressed by backpressure resume, and file descriptors remain
  owned until asynchronous sendfile work completes instead of being eligible for
  reuse while a response is still in flight.
- Updated the released dependency graphs to clear newly published advisories:
  `fasthttp` v1.70.0 (GO-2026-4950), `klauspost/compress` v1.18.7
  (GO-2026-5841), `x/text` v0.39.0 (GO-2026-5970), `x/net` v0.56.0
  (GO-2026-5942), `x/sys` v0.46.0 (GO-2026-5024), and OpenTelemetry
  v1.44.0 (GO-2026-5158). The checked-in database benchmarks also use
  `pgx/v5` v5.9.2, clearing GO-2026-5004.

  Kruda does not call the affected fasthttp file-serving symbols or
  `compress/s2` directly. Applications that obtain a `*fasthttp.RequestCtx`
  through `RawRequest()` and serve an authorized filesystem path should use the
  v1.70 `SendFileLiteral`/`ServeFileLiteral` variants so a second URI decoding
  pass cannot reinterpret the checked path.
- Every tagged contrib module now requires Kruda core v1.7.2 or newer, so Go's
  minimum version selection cannot pair these updates with a core version that
  predates the transport and toolchain hardening above.

### Changed

- Raised the minimum Go patch level from 1.25.11 to **1.25.13** across the core,
  CLI, contrib modules, templates, examples, benchmarks, documentation and CI.
- The FastHTTP transport inherits v1.70's stricter request parsing. Requests with
  missing or duplicate `Host` headers, whitespace before a header colon, invalid
  request targets, or malformed chunk extensions or trailers may now be rejected;
  well-formed HTTP traffic is unchanged.

### Documentation

- Added a source-derived guard that rejects validation examples naming rules
  Kruda does not implement or register, covering the README, site guides, API
  pages, Go doc comments and runnable examples. The typed-handler tag legend now
  uses the real `required,min=2` rules instead of a placeholder.

## [1.7.1] — 2026-08-03

### Breaking

- **Validation now runs by default.** `validate` tags on typed-handler and
  `Resource` inputs are enforced without configuration; previously they were inert
  unless a `Validator` was set, so an application carrying them may start
  rejecting requests it used to accept, with 422 and a per-field error body. Opt
  out with `kruda.New(kruda.WithoutValidation())`. `kruda.WithValidator` remains,
  but is now only for registering custom rules or messages.

  `(*kruda.Validator).RuleNames()` reports the rules a validator recognises —
  the 20 built in, plus anything registered. The tag syntax resembles
  `go-playground/validator`, which has far more, and tags carried over from it are
  the likely surprise here: `eq`, `ne`, `datetime`, `required_if`, `hexcolor` and
  others do not exist and are skipped with a startup warning.

### Added

- **The `omitempty` and `dive` validation modifiers.** `omitempty` skips a field's
  rules when its value is the zero value; `dive` applies every rule after it to each
  element of a slice, array or map instead of to the container, and names the failing
  element — `tags[2]`, `limits[free]` — rather than just the field.

  These had to land with validation-by-default rather than after it. A *modifier* is
  not a constraint: skipping an unknown constraint only relaxes validation, but
  skipping a modifier applies the rules around it in the wrong place. Measured before
  the fix, `validate:"omitempty,min=10"` rejected an empty optional field, turning it
  into a required one, and `validate:"omitempty,dive,uuid"` on a `[]string` rejected
  **every** input including a slice of valid UUIDs, because `uuid` ran against the
  slice itself. Both are common tags carried over from `go-playground/validator`, so
  enabling validation without them would have broken working applications in a way no
  warning explained.

  Resolved entirely at route registration: `omitempty` becomes a flag and `dive`
  splits the rule list, so nothing is re-parsed per request. Paired A/B on the typed
  handler path shows no change — 56 B/op and 6 allocs/op identical, ns/op within
  noise once run-order effects are controlled for. `dive` on a field that is not a
  collection is inert and warns at startup.

  They are deliberately absent from `RuleNames()`: they carry no `ValidatorFunc` and
  cannot be added with `Register`.

- An unknown validation rule no longer panics at route registration; it is skipped
  and reported once at startup with the rule, type, field and the list of rules
  that do exist. This had to change before validation could default on: while
  validation was opt-in, a tag naming a rule Kruda does not implement never
  reached the compiler for it, so applications carrying `omitempty` run today.
  Panicking would have turned enabling validation into a failure to start rather
  than a stricter response. Applications that already configured a `Validator` are
  unaffected — an unknown rule there panics already, so none that boot today have
  one.

- Removed the startup warning that fired when `validate` tags were found with no
  `Validator` configured. It existed to surface tags that silently did nothing;
  they no longer do.

  **This is a patch release that changes behaviour.** Kruda's version numbers signal
  how much attention a release needs rather than a semver guarantee, so read this
  section before taking it — do not auto-merge it. Reasoning:
  `docs/decisions/0002-breaking-changes-after-adoption.md`.

  What to check before upgrading:

  ```bash
  grep -rn 'validate:"' --include='*.go' .
  ```

  - **Every tag that grep finds is now enforced.** Requests that did not satisfy one
    were served before and get a 422 now. The ones to look at first are fields whose
    tags were written aspirationally and never tested, since nothing has been
    checking them.
  - **Tags naming a rule Kruda does not have are skipped, not enforced** — so a field
    you believe is validated may still not be. Kruda implements 20 rules plus the
    `omitempty` and `dive` modifiers; `eq`, `ne`, `datetime`, `required_if` and
    `hexcolor` are among the `go-playground/validator` tags that do not exist here.
    Each one logs a warning at startup naming the rule, the type and the field: read
    that log once after upgrading. Skipping these only relaxes validation, so none of
    them can cause a rejection that did not happen before.
  - **Tests that assert a 2xx for invalid input will start failing.** That is the
    cheap way to find the affected endpoints — it happens at test time rather than in
    production.
  - **`kruda.WithValidator` no longer switches validation on**, because it is already
    on. If you passed it only for that, it is now redundant; keep it only for custom
    rules or messages.


## [1.7.0] — 2026-07-30

### Upgrade note — `CGO_ENABLED=0` builds: JSON response bytes change

If you build with `CGO_ENABLED=0`, this release changes which JSON engine you get
and therefore what your responses look like on the wire. Nothing else in this
release does that, and it is easy to miss because no build flag of yours changed.

Before this release a `CGO_ENABLED=0` build silently got `encoding/json`, which
escapes `<`, `>` and `&` in strings. It now gets Sonic, which is configured with
`EscapeHTML` off. Measured on the same input:

| string in a response | before | after |
|---|---|---|
| `if x < 10 && y > 3` | `"if x \u003c 10 \u0026\u0026 y \u003e 3"` | `"if x < 10 && y > 3"` |
| `<p>Chapter 1</p>` | `"\u003cp\u003eChapter 1\u003c/p\u003e"` | `"<p>Chapter 1</p>"` |
| `{"title": "A & B"}` | `{"title":"A \u0026 B"}` | `{"title":"A & B"}` |

Enabling CGO does **not** avoid this — CGO no longer takes part in choosing the
engine, which is the point of the fix below. `-tags kruda_stdjson` is the only way
to keep the previous behaviour.

What to check before upgrading:

- **Anything keyed on response bytes** — `contrib/etag`, response caches, snapshot
  tests, anything diffing or signing a raw body — will miss once as bodies change.
  This is the whole of the practical impact.
- **Anything that consumes the body without parsing it as JSON.** A client calling
  `res.json()` is unaffected — see the correction below.

> **Correction (2026-07-31).** This section originally led with a warning about
> `innerHTML`, `dangerouslySetInnerHTML` and `v-html` fed from a response, on the
> grounds that "escaped output was masking `<` and `&` for you". That is wrong, and
> it sent at least one upgrade pre-flight looking in the wrong place. The JSON
> escape \u003c and a literal `<` are two encodings of the same character, so **every
> conformant parser yields an identical value** — verified by marshalling the same
> struct with `EscapeHTML` on and off and parsing both: the wire bytes differ, and
> `JSON.parse` returns the same string. The escaping never survived to the DOM, so
> it was never masking anything for a client that parses JSON, and the XSS posture
> of a raw-HTML sink is exactly what it was before this release. Byte-level
> consumers remain genuinely affected.

If you would rather keep the escaping and the speed, `kruda.WithJSONEncoder` can
supply a Sonic config with `EscapeHTML` on, at roughly 41% on responses containing
strings. Note that a custom encoder also disables the streaming response path.

### Security

- `contrib/observability` now requires `google.golang.org/grpc` v1.82.1, clearing
  GO-2026-6061. The vulnerable v1.81.1 arrived indirectly through the OTLP gRPC
  exporters, and govulncheck reported it as reachable from
  `observability.buildSDK`. The weekly scan on 2026-07-26 was clean, so the
  advisory landed after it; the finding came from the on-PR scan.

### Fixed

- `kruda new` now produces a project that builds. All three templates wrote
  `require github.com/go-kruda/kruda v0.0.0`, a placeholder no proxy can
  resolve, so `go mod tidy` — the second step the CLI itself prints — failed,
  and so did `go build` and `go run`. `go get github.com/go-kruda/kruda@latest`
  failed too, because Go resolves the existing requirement before fetching
  anything, leaving no recovery short of editing `go.mod` by hand. `kruda mcp`
  prints the same steps and the scaffold ships `.mcp.json`, so AI-assisted users
  hit the same wall. The templates no longer pin the core module at all: `go mod
  tidy` resolves the current release, so nothing here goes stale at the next tag.
  Broken since 2026-03-01, across v1.4.0 through v1.6.2.
- The `api` and `fullstack` templates called `c.Status(204).Send(nil)`; `Send` is
  unexported. They now use `c.NoContent()`.
- `kruda --version` reported `dev` for anyone who installed the published
  binary, since the version is only injected by `-ldflags` in a release build.
  It now falls back to the module version recorded in the binary.
- `kruda validate` printed the full usage block when a check failed, pushing the
  message that says what to fix off the top of the output. Every CLI error was
  also printed twice, once by cobra and once by the entry point.
- `kruda dev` announced `Port: N / Listening on :N`, which was wrong for any app
  that hardcodes its `Listen` address — it only passes `PORT` to the child
  process. It now says exactly that.

- JSON responses are now always valid UTF-8. The Sonic engine copied invalid
  UTF-8 in a string straight through, so a string holding a truncated multi-byte
  sequence, text read from a legacy encoding, or arbitrary binary produced a
  response body that was not valid UTF-8 — which RFC 8259 section 8.1 requires
  for JSON exchanged between systems, and which a strict client or proxy may
  reject. The engine now enables `ValidateString`, substituting U+FFFD as
  `encoding/json` already did, making the two engines byte-identical for these
  inputs. It costs about 8% on responses containing a string.

  `EscapeHTML` remains off, and is now the only byte-level difference between the
  two engines: `encoding/json` escapes `<`, `>` and `&` so its output is safe to
  paste directly inside an HTML `<script>` tag, and the Sonic engine emits those
  characters. Enabling it costs about 41% on every response containing a string,
  a poor trade for a default when responses are served as `application/json`,
  which no browser executes, and the `html/template` renderer escapes JSON it
  embeds. Applications that hand-embed a response body into HTML can opt in with
  `kruda.WithJSONEncoder`.

- The Wing blocking advisor no longer warns about routes that do not block. It
  judged a route by an absolute count of long inline requests, but inline time is
  wall time and so includes any delay the OS scheduler adds. On a CPU-saturated
  machine — a load test, a noisy neighbour, a pod at its CPU limit — even a
  handler that only writes a constant string is occasionally descheduled past the
  100µs threshold, and at a few hundred thousand requests a second the count of
  ten was reached within seconds. A `c.Text` handler serving 190k req/s was told
  to add `kruda.DB`. The advisor now warns only when at least 20% of a route's
  requests run long, over at least 200 requests, which separates a genuinely
  blocking handler (blocks on essentially every request) from scheduler noise
  (well under 1%) by orders of magnitude. The warning now also reports
  `share_percent`. Verified end to end: a handler sleeping 2ms warns at
  `share_percent=100`, while a plaintext route at 181k req/s on the same server
  stays silent.

  Measuring a share means counting every inline request rather than only the long
  ones, so the counting itself is kept off the hot path: each Wing worker tallies
  its own routes in memory it alone owns — no atomic, no lock, and no allocation
  once a route has been seen — and folds those tallies into the shared per-route
  totals in batches, when a batch fills, when enough long requests accumulate to
  possibly warn, when the route changes, or when the worker stops. Observing a
  request costs two string comparisons and an increment.

  A batch always carries long requests together with the totals they were drawn
  from, which is what keeps the share honest across workers: publishing a long
  request on its own, against totals still sitting unflushed in every other
  worker, would make a route look far more blocking than it is — worst at process
  start, when each worker is a few requests in and scheduler noise peaks.

  The 1024-route cap that guards against a flood of distinct paths remains
  process-wide, and continues to apply only to routes the process has not seen
  before: a route already being tracked keeps resolving on every worker, however
  full the cap, so a flood cannot silence the advisor for an application's real
  routes.

- ETag generation no longer breaks for handlers that return a multi-key map. The
  Sonic engine left `SortMapKeys` off, so map output followed Go's randomized map
  iteration order and the same logical response serialized to different bytes on
  every request. Anything deriving a value from response bytes saw a new value
  each time: `contrib/etag` hashes the body, so `If-None-Match` never matched and
  304 was never returned — conditional-request caching silently did nothing.
  Measured with a 4-key `map[string]any`, ETag generation produced 4 distinct
  ETags across 200 requests before this change and 1 after. Response caching keyed
  on body bytes and response snapshot tests were affected the same way. Struct
  responses were never affected, and the `kruda_stdjson` engine was never
  affected because `encoding/json` always sorts map keys.
- `contrib/etag`: the `New` doc example generated the ETag from one marshal of the
  payload and then responded with `c.JSON(data)`, encoding the value a second time.
  Besides the wasted encode, the ETag was not guaranteed to describe the bytes
  actually sent. The example now responds with the same bytes it hashed, via
  `c.SendBytesWithType`.
- `json.MarshalToBuffer` on the Sonic engine now uses Sonic's streaming encoder,
  as its documentation already claimed. It previously called `sonic.Marshal` and
  copied the result into the buffer, so it allocated the intermediate `[]byte`
  it was meant to avoid — on the response path used for every JSON response.
  Against the implementation it replaces, encoding a 100-item payload drops from
  ~9800 B/op to 113 B/op and is about 35% faster; a single-item payload costs
  about 26 ns more for 127 B/op → 112 B/op. It encodes through the same
  configuration as `json.Marshal`, so both produce identical bytes.

  Figures are medians of 12 runs on linux/amd64, and two independent samples put
  the large-payload gain at 33.8% and 36.2% and the single-item cost at 25.4 ns
  and 27.9 ns — hence the rounded values rather than a spuriously precise one.
  The baseline is `BenchmarkMarshalToBufferLegacy` in
  `json/engine_bench_legacy_test.go`, which is the old body verbatim —
  `sonic.Marshal` on the package default config, which is what it really called —
  rather than today's configured encoder; the rest live in
  `json/engine_bench_test.go`. On darwin/arm64 Sonic's encoder is slower than
  `encoding/json`, so these are amd64 figures.

### Added

- Startup warning when a typed route's input carries `validate:` tags but no
  `Validator` is configured. Validation is opt-in, so those tags were silently
  inert: the request was parsed, nothing was checked, and the handler received
  whatever the client sent. The warning fires once per process at route
  registration, naming a route and field, and says which option enables
  validation. Nothing is added to the request path.

### Changed

- Docs: every place that described validation as automatic now states that it is
  opt-in. This was wrong in the README, the `C[T]` package doc, `docs/api/handler.md`,
  `docs/guide/handlers.md`, the four `coming-from-*` guides, the typed-handler
  example's comments, `CLAUDE.md`, and — most consequentially — the `kruda mcp`
  documentation topics, which told AI assistants "Kruda validates struct tags
  automatically in typed handlers" and never mentioned `WithValidator` anywhere.
  Since `kruda new` ships `.mcp.json`, that was the default guidance for
  AI-assisted users. Samples that show `validate:` tags now build the app with
  `kruda.WithValidator(kruda.NewValidator())`, and the docs note that the
  generated OpenAPI schema advertises the constraints whether or not they are
  enforced. `TestMCPDocsDoNotTeachAutomaticValidation` keeps the AI-facing
  guidance honest; it caught the file-upload topic, whose `max_size`/`mime` tags
  were presented as if they applied on their own.
- Docs: the `kruda mcp` file-upload sample was broken in two further ways. It
  named `*kruda.Upload`, a type the core does not export (it is
  `kruda.FileUpload`), so the sample could not compile; and it wrote
  `validate:"required" max_size:"5mb" mime:"image/*"`, putting two validation
  rules into struct tags of their own. Only `required` compiles from that form —
  `max_size` and `mime` are never read, so an upload of any size or type was
  accepted even with a validator configured and the limits visible in the
  source. Rules belong inside the `validate` tag. Guarded by
  `TestMCPDocsUseValidationRulesAsRules` and `TestMCPDocsReferenceRealCoreTypes`.
- Docs: every upload sample documented `max_size=5mb` against the 4MB default
  `BodyLimit`, so the rule could never fire. `BodyLimit` is enforced by the
  transport before the handler runs, so anything larger is answered 413 and
  never reaches validation — measured end to end, a 4.5MB upload returns 413,
  not the 422 the docs describe, and the 5MB cap a reader thought they had set
  was really a 4MB one with a different status code. The samples in `upload.go`,
  `docs/guide/security.md` and the `kruda mcp` file-upload topic now raise
  `WithBodyLimit` alongside the rule and state the ordering.
  `TestDocumentedMaxSizeIsReachable` fails on any documented `max_size` above the
  default `BodyLimit` that does not raise it.

- The Sonic JSON engine now sorts map keys, so marshalling the same map twice
  always produces the same bytes. Response bytes change for handlers that return
  a multi-key map: keys are now emitted in sorted order, matching the
  `kruda_stdjson` engine and `encoding/json`. Struct responses — including all
  typed handlers and `Resource` CRUD — are unaffected, since struct field order
  is fixed at compile time, and measure unchanged at ~165 ns/op. Map marshalling
  costs roughly 13% more for a 4-key map and 65% for a 50-key map.
- The `listening` startup log line now reports the active JSON engine as
  `json=sonic`, `json=encoding/json`, or `json=sonic (fallback: encoding/json)`,
  naming what is actually encoding. The third is genuinely distinct: Sonic's API
  is still in front, so its `EscapeHTML` setting is honoured and the HTML-escaping
  divergence between the engines does not appear, while the standard library does
  the work, so the speed is not Sonic's. Output beyond escaping is untested on a
  fallback rather than guaranteed identical. A fallback is reachable today, not
  hypothetical: `linux/ppc64le`, `s390x`, `riscv64`, `mips64` and `loong64` build
  and take it; CI covers amd64 and arm64 only, so none of it is exercised. On
  32-bit the default build does not compile at all, because Sonic refuses to; on
  `linux/arm` the `kruda_stdjson` tag drops the dependency and builds, while
  `linux/386` cannot be built at all for an unrelated reason — Wing's Linux
  engine uses `syscall.SYS_ACCEPT4`, undefined for 386. Sonic applies its own platform and Go-version constraints on top of
  Kruda's tag and can route its API to `encoding/json` — an architecture it has no
  assembly for, or a Go version it has not validated, such as go1.27 and newer for
  sonic v1.15.0. `json.ActiveEngine` resolves that, and Kruda now selects its JSON
  response path from it too, so a fallback build takes the path that suits
  `encoding/json` instead of the one that suits Sonic. `json.EncoderName` still
  names what the tag selected, for callers that want that.
- The Sonic JSON engine no longer requires CGO. `json/sonic.go` was gated on the
  `cgo` build constraint, so any `CGO_ENABLED=0` build — the common setting for
  static binaries and `scratch`/`distroless` container images — silently fell
  back to `encoding/json` while still reporting a default build. Sonic is pure
  Go plus assembly and has no cgo dependency. CGO no longer takes part in the
  choice: the `kruda_stdjson` tag selects `encoding/json`, and without it Kruda
  selects Sonic, which then applies its own constraints — amd64/arm64 on Go
  versions it has validated — and routes to `encoding/json` itself outside them.
  Sonic v1.15.0 excludes Go 1.27 and newer, so a toolchain upgrade can still
  change the engine without any change to build flags.

  This changes behavior for existing `CGO_ENABLED=0` builds, which now get
  Sonic: JSON decoding is about 6× faster (78.1 → 13.0 µs for a 100-item
  payload), at the cost of Sonic's JIT warm-up at process start — cold start
  3.25 ms → 6.25 ms and startup RSS 12.5 MB → 19.4 MB, median of 15 spawns on an
  8-core linux/amd64 host. The warm-up is a fixed cost paid once per process, not
  one that scales with how many typed routes are registered: going from 1 route
  to 25 moves cold start by about 0.25 ms in either engine. Long-lived servers
  recoup it within the first few thousand requests; builds that spawn a process
  per request or scale to zero should set the `kruda_stdjson` tag to keep the
  faster cold start. Reproduce with `bench/reproducible/coldstart/coldstart.sh`
  (results and method in `bench/reproducible/results/2026-07-29-coldstart/`).

## [1.6.2] — 2026-07-19

### Security

- `App.Static` now resolves files through a rooted filesystem, preventing
  symlinked files, directories, directory indexes, and SPA fallback indexes from
  serving content outside the configured root. Regular files and relative
  in-root symlinks continue to work.

### Changed

- `App.Static` now opens its configured root when called, keeps it open until
  `App.Shutdown`, and panics with the root path when the directory cannot be
  opened.
- Docs: updated `contrib/ws` examples and package documentation to register
  WebSocket routes with `ws.HandleFunc`, which applies `kruda.Hijack` for Wing;
  Wing and net/http are supported, while fasthttp remains unsupported.
- Docs: corrected typed-handler validation, build-time JSON engine selection,
  independent nested-module versioning, and unscoped performance claims.

## [1.6.1] — 2026-07-18

### Added

- Startup warning when `Use()` is called after routes are registered (the
  middleware would silently not apply to the already-registered routes).
- Docs: Wing protocol support matrix (`docs/guide/wing-protocol-support.md`) and
  production TLS deployment guidance (terminate in front of Wing).

### Changed

- CI and pre-release validation now exercise both the default Sonic JSON engine
  and the `kruda_stdjson` fallback, preventing engine-specific regressions.
- Benchmark runs now cover changelog-only release preparation commits, ensuring
  the exact tagged `main` commit satisfies the green-release preflight.
- Removed the stale `transport/wing v1.1.3` require from `go.mod` (the shim
  directory was removed in v1.3.0; nothing imports it).
- Docs: corrected the stale "Wing doesn't support SSE" transport limitation —
  SSE works via the `kruda.Stream` preset since v1.5.0.
- Docs: corrected `App.Serve` — it claimed systemd socket activation
  unconditionally, but Wing (default on Linux) closes the passed listener and
  re-binds one `SO_REUSEPORT` socket per worker, so it cannot serve an inherited
  fd. The net/http and fasthttp transports serve the supplied fd directly; the
  doc comment and transport guide now say which transports honor fd-passing.
- MCP server (`kruda mcp`): corrected stale AI-facing guidance that predated the
  streaming/WebSocket presets. `kruda_docs` gains a `websocket` topic and its
  `sse`/`wing` topics now document the `kruda.Stream` preset (v1.5.0+) instead of
  claiming SSE/streaming has no Wing preset; `kruda_suggest_wing` now suggests
  `kruda.Stream` for SSE/streaming routes and `kruda.Hijack` for WebSocket routes
  instead of "none". Keeps AI-generated code aligned with real-time on Wing.

### Fixed

- Health-checker discovery no longer panics when the dependency container holds
  services whose dynamic values are not comparable (for example, structs with
  slice or map fields).
- `contrib/ws` now closes orphan continuation frames with protocol error 1002,
  rejects malformed close payloads before echoing them, and validates complete
  text messages and close reasons as UTF-8 (closing with 1007 when invalid).
- The standalone WebSocket example now resolves against the published v1.6.0
  core module instead of an older pre-Wing-WebSocket version.

## [1.6.0] — 2026-07-04

### Security

- **`contrib/ws` frame-parser hardening (RFC 6455 §5).** `readFrame` now rejects
  undefined/reserved opcodes, fragmented control frames, and control frames whose
  declared payload exceeds 125 bytes (the last closes an unbounded-allocation DoS
  that was reachable before the payload buffer was sized), and rejects non-minimal
  length encodings. `Conn.ReadMessage` now rejects unmasked client frames
  (RFC 6455 §5.1). These gaps were latent while WebSocket ran only on net/http;
  they are fixed here as WebSocket support extends to the Wing transport.

### Fixed

- Wing no longer drops request headers: requests carrying more than 8
  non-fast-path headers now spill into a heap slice instead of being silently
  dropped past the 8th. Real browser requests (e.g. a Chrome WebSocket upgrade
  carries ~10-12 non-fast headers) previously lost every extra header past the
  8th — `c.Header()` returned "" for them. The inline fast path (≤8 extra
  headers) is unchanged, so the zero-extra-header hot path keeps its footprint.
- Wing now retains the `Connection` request header value, so
  `c.Header("Connection")` returns it. Previously Wing parsed `Connection` only
  to derive keep-alive and dropped the raw value (always returning ""), which
  broke the WebSocket upgrade handshake (`Connection: Upgrade`) on Wing. The fix
  uses the same zero-copy path as `Host`/`Accept`, so the hot path stays zero-alloc.

### Added

- **WebSocket on the Wing transport.** `contrib/ws` now works on Wing (the
  default on Linux), previously net/http-only. Register with
  `ws.HandleFunc(app, "/ws", handler)` — identical on every transport. Internally
  Wing hands the taken-over connection to `contrib/ws` via the standard
  `http.Hijacker` contract (a new generic `kruda.Hijack` route preset); the
  RFC 6455 frame code is reused unchanged. Dispatches via Takeover, so the inline
  hot path is untouched. A pipelined first frame is preserved, a rejected upgrade
  returns a clean 4xx, and on shutdown Wing wakes I/O-blocked handlers
  (`SHUT_RDWR`) and signals `conn.Done()` so a handler blocked in application
  logic can exit cooperatively. The fasthttp transport still does not support
  WebSocket.
- `App.Serve(ln net.Listener)` — run the app on a pre-created listener instead of
  binding an address, for graceful restart, systemd socket activation, or tests
  that need the bound address before the server accepts (no signal handler; the
  caller owns the lifecycle via `Shutdown`).
- `WingHeaderSpills()` — process-wide counter of requests whose extra headers
  spilled past the inline capacity (observability for header-heavy traffic).

## [1.5.0] — 2026-06-29

### Added

- **Server-Sent Events and streaming on the Wing transport.** `c.SSE()` and `c.Stream()`
  now work on Wing (the default on Linux) via the new `kruda.Stream` route preset —
  `app.Get("/events", h, kruda.Stream)`. Previously they returned an error unless the route
  ran on net/http. Streaming dispatches via Takeover and does not affect the inline hot
  path; a slow/stuck client is bounded by `WriteTimeout`, and a client disconnect cancels
  the handler context (`SSEStream.Done()` fires). A `TestClient.SSE(path)` helper decodes the
  emitted events for unit tests. The fasthttp transport (macOS dev default) does not support
  streaming — `c.SSE()` there now returns an actionable error pointing to `kruda.NetHTTP()`.
- **`WithHeaderLimit(n)` option.** Configures the maximum total request-header size
  (default 8 KB → HTTP 431). Clients sending large `Authorization`/`Cookie` headers (big
  JWTs) previously hit a spurious 431 with no escape hatch.
- **Environment configuration for the Wing safety bundle.** `WithEnvPrefix` now also reads
  `<PREFIX>_HEADER_LIMIT`, `<PREFIX>_TRUST_PROXY`, `<PREFIX>_MAX_CONNS`,
  `<PREFIX>_MAX_CONNS_PER_IP`, `<PREFIX>_ACCEPT_RATE_PER_SEC`, and
  `<PREFIX>_ACCEPT_RATE_BURST`, so Kubernetes/ConfigMap deployments can tune the v1.4.0
  accept-side DoS limits and proxy trust without code changes.

### Security

- Raised the minimum Go to **1.25.11** (1.25 line) or **1.26.4** (1.26 line). go1.25.10
  and go1.26.0–1.26.3 carry stdlib CVEs GO-2026-5037 (crypto/x509 quadratic verify) and
  GO-2026-5039 (net/textproto error-message injection); the new floor clears both.

### Breaking

- **Removed the no-op `WithHTTP3` option and the `Config.HTTP3` field.** They advertised
  HTTP/3 (QUIC) serving, but it was never implemented — nothing consumed the flag, so a
  caller got the standard net/http fallback (HTTP/1.1 + HTTP/2), not QUIC. HTTP/3 is not on
  the roadmap, so the dead API is removed rather than left as a misleading promise
  (rationale: `docs/decisions/0001-break-api-in-v1-minor.md`). TLS is unaffected — use
  `WithTLS(certFile, keyFile)`.

## [1.4.0] — 2026-06-27

### Breaking

The Wing accept-limit work removed the now-dead per-worker connection field in favor
of server-wide options. With effectively zero external adopters, the removal ships in a
v1 minor release — rationale in `docs/decisions/0001-break-api-in-v1-minor.md`. Migration:

| Removed | Replacement |
|---------|-------------|
| `WingConfig.MaxConnsPerWorker` | `kruda.WithMaxConns(n)` (total cap) — plus `kruda.WithMaxConnsPerIP(n)` and `kruda.WithMaxAcceptRate(perSec, burst)` for per-IP and accept-rate limits |

The semantics also change from a **per-worker** cap to a **server-wide total** cap, so size
the new value as the old per-worker limit times the worker count (workers default to
`runtime.NumCPU()`):

```go
// before — per-worker cap (effective total ≈ MaxConnsPerWorker × worker count)
kruda.New(kruda.Wing(kruda.WingConfig{MaxConnsPerWorker: 1024}))
// after — single server-wide total cap (e.g. 1024 × 8 workers)
kruda.New(kruda.Wing(), kruda.WithMaxConns(8192))
```

### Fixed

- **Wing now honors the request-size contract on both read paths.** The default
  Wing transport previously ignored `BodyLimit`/`HeaderLimit`/`TrustProxy` and
  silently dropped any request body larger than its fixed read buffer (~8 KB).
  Wing now accepts legal bodies of any size up to `BodyLimit` (incrementally
  accumulated, capped by `BodyLimit` plus a per-worker in-flight budget) and
  returns deterministic **413** (body over limit), **431** (headers over limit),
  and **501** (chunked request bodies — Wing does not dechunk) before the handler
  runs, on both the event-loop and Takeover paths. `Expect: 100-continue` is
  answered (or rejected with 413) before the body is read, read deadlines bound
  the whole request read, and `TrustProxy` reads `X-Forwarded-For`/`X-Real-IP`
  with the same boolean semantics as net/http. The no-body hot path is unchanged
  (parser fast path frozen, 0-alloc guard; tiger A/B shows no regression).
- **Wing no longer double-closes a Takeover connection's fd on shutdown.**
  Graceful shutdown discarded the `*os.File` that owns a Takeover connection's
  fd without closing it while also raw-closing the same fd; the leaked File's
  finalizer then closed the fd after the kernel had recycled the number for a
  new socket, surfacing as intermittent `bad file descriptor` errors on a
  subsequent `net.Listen`/`net.Dial` when Takeover-preset servers were restarted
  under load. Shutdown now closes each Takeover fd exactly once.
- **Wing bounds total in-flight body memory across both read paths.** The Takeover
  path now charges and refunds the per-worker in-flight body budget
  (`MaxInflightBodyBytes`), returning **503** when the budget is exceeded, so the
  event-loop and Takeover paths share one bound on concurrent body memory. Pipelined
  bytes that arrive in the same read as a request body are preserved — surplus past
  `Content-Length` is relocated, and already-buffered pipelined bytes are drained once
  the body completes (edge-triggered epoll does not re-notify for bytes already in the
  read buffer).
- **Logger middleware records real request latency.** The built-in Logger reported a
  latency of `0` for every request; it now measures and logs the actual handler
  duration.
- **Prometheus in-flight gauge no longer leaks on panic.** The in-flight request gauge
  `Dec` is now deferred, so a panic inside a handler can no longer leave the gauge
  permanently incremented.

### Added

- **Typed test-client helpers for typed handlers.** `GetTyped`, `PostTyped`,
  `PutTyped`, `PatchTyped`, `DeleteTyped`, and `SendTyped` wrap the existing
  in-memory `TestClient` and decode JSON responses into a typed
  `TypedTestResponse[T]`, while body helpers accept typed request values.
- **Richer OpenAPI metadata for typed routes.** Generated OpenAPI 3.1 specs can
  now include explicit security schemes, per-route security requirements,
  request/response examples, and error response content schemas aligned with
  the default Kruda error shape or `WithProblemJSON()`.
- **Opt-in RFC 9457 problem+json error responses.** `kruda.New(kruda.WithProblemJSON())`
  renders errors as `application/problem+json` (standard members plus a field-level
  `errors` array for validation failures). Off by default — the standard error shape is
  unchanged; `WithErrorHandler` still takes precedence.
- **Fluent `KrudaError` builders** — `WithType`, `WithDetail`, `WithInstance`, and
  `With(key, value)` for problem `type`/`detail`/`instance`/extension members, e.g.
  `kruda.NotFound("…").WithType("https://…").With("userId", id)`.
- **Wing accept-side DoS limits.** New options `WithMaxConns(n)`,
  `WithMaxConnsPerIP(n)`, and `WithMaxAcceptRate(perSec, burst)` cap accepted
  connections at the accept path: a global total cap (CAS-reserved; when unset, derived
  from `RLIMIT_NOFILE` at Wing startup), an opt-in per-IP concurrent-connection limit,
  and an accept-rate token bucket. Enforcement is accept-only — over-limit connections
  are closed with a TCP **RST**, never an HTTP **503**. The peer IP is captured zero-alloc
  via raw `accept4`. These thread the new `WingConfig` fields `MaxConns`,
  `MaxConnsPerIP`, `AcceptRatePerSec`, and `AcceptRateBurst`. Per-IP caps key on the
  socket peer address, not `X-Forwarded-For`. Linux/epoll only enforces the accept path;
  the no-limit hot path is unchanged (tiger A/B shows no regression).
- **Turnkey observability — new `contrib/observability` module.** A single
  `observability.Enable(app, cfg)` call wires OpenTelemetry tracing (otel v1.44.0),
  RED metrics, trace/log correlation, Kubernetes liveness/readiness probes, and a
  `/metrics` endpoint. The core gains a `WithLogEnricher(fn)` option and
  `App.SetLogEnricher(fn)` seam for attaching per-request log attributes (e.g. the
  active trace/span IDs).
- **Auto-CRUD `Resource` input validation and OpenAPI 3.1 schemas.**
  `kruda.Resource` create/update routes now decode and validate the request body
  through the typed-handler contract (gated identically to typed routes — Validator
  configured and `T` carrying validation tags), return **400** on bad pagination, and
  emit explicit OpenAPI 3.1 operations (list/get/create/update/delete) with correct
  `200`/`201`/`204` status codes, page/limit query params, a request body, a `422` only
  when validation is engaged, and the same default error response as typed routes.
  Generic instantiation component names (e.g. `ResourceList[…/models.User]`) are
  sanitized to valid JSON-pointer `$ref` names.

## [1.3.1] — 2026-06-13

### Changed

- **Wing: adaptive spin before the netpoller park on Takeover keep-alive reads.**
  Recovers the `/db` and `/queries` throughput-p99 wake-hop introduced by the
  v1.3.0 netpoll takeover. On the default build versus Fiber, every DB-route cell
  now beats Fiber on p99 (−6.6% to −28.9%) while matching it on RPS at the pgx
  ceiling — the v1.3.0 "trades a few milliseconds of db/queries p99" caveat is
  removed. The spin is bounded (`takeoverSpinReads`) and reached only by Takeover
  dispatch (DB/Render routes); DB-bound routes have idle CPU, so it trades that
  idle for a shorter tail at no throughput cost. Evidence:
  `bench/reproducible/results/2026-06-13-takeover-spin-p99-evidence.md` and
  `2026-06-13-v1-3-1-consolidated-evidence.md`.

### Added

- `bench/reproducible/footprint.sh` — runtime footprint measurement (binary size,
  startup time, RSS).
- `bench.sh` opt-in low-concurrency profiles (`BENCH_LOWC=1` → c8/c16/c32).
- `TestStringLaneZeroAlloc` — guards the Wing string lane's zero-allocation
  property against regression.

### Notes — performance audits (no code change)

- Allocation: the Wing hot path is already allocation-optimal (Ctx pool and the
  string lane are 0 allocs/op). Footprint: Linux startup 5 ms, idle RSS 13.8 MB.
  Low-concurrency: Kruda leads RPS at every concurrency and leads p99 from c16 up.
  Evidence files under `bench/reproducible/results/2026-06-13-*`.

## [1.3.0] — 2026-06-13

### Breaking

The per-route tuning API was renamed to match the Kruda model: a route rides
a Preset composed from Wing's internals. With effectively zero external
adopters, the rename ships as a v1 minor release instead of a v2 — rationale
in `docs/decisions/0001-break-api-in-v1-minor.md`. Migration table:

| v1.2.x | v1.3.0 |
|--------|--------|
| `kruda.WingPlaintext()` | `kruda.Plaintext` |
| `kruda.WingJSON()` | `kruda.JSON` |
| `kruda.WingQuery()` | `kruda.DB` |
| `kruda.WingRender()` | `kruda.Render` |
| `kruda.WingFeather(f)` | pass the `Preset` value directly as a route option |
| `kruda.WingStaticText(...)` | `kruda.StaticText(...)` |
| `kruda.WingStaticJSON(...)` | `kruda.StaticJSON(...)` |
| `kruda.Feather` / `kruda.FeatherOption` | `kruda.Preset` / `kruda.PresetOption` |
| `kruda.FeatherTable` / `kruda.NewFeatherTable` | `kruda.PresetTable` / `kruda.NewPresetTable` |
| `WingConfig.Feathers` / `.DefaultFeather` | `WingConfig.Presets` / `.DefaultPreset` |
| `transport.FeatherConfigurator.SetRouteFeather` | `transport.PresetConfigurator.SetRoutePreset` |
| `transport.StaticTextResponder` | removed — `c.Text`/`c.HTML` ride the string fast lane |
| `RouteOption` (func type) | interface — presets implement it; custom func options wrap internally |
| `KRUDA_ASYNC`, `KRUDA_POOL_ROUTES`, `KRUDA_SPAWN_ROUTES`, `KRUDA_STATIC` | removed — use route presets or `WingConfig.Presets` |
| `github.com/go-kruda/kruda/transport/wing` | removed — import `github.com/go-kruda/kruda` (tags up to `transport/wing/v1.1.3` keep working for pinned users) |

### Added
- Wing string response fast lane: `c.Text` and `c.HTML` now serialize
  status + Date + Content-Type + Content-Length + body in one zero-copy pass
  (twin of the JSON fast lane), with automatic fallback to the standard path
  when headers, cookies, or secure headers are configured.
- `transport.StringResponder` optional transport interface.
- Blocking advisor: a route left on inline dispatch that blocks the event
  loop (>100µs wall time, 10 times) logs one warning per route per process
  suggesting `kruda.DB` or `kruda.Spear`. Observation only — no dispatch mode
  is ever switched automatically.
- Registration-time `slog.Debug` line for preset-annotated routes.

### Changed
- Takeover dispatch parks connections on the runtime netpoller instead of
  pinning one OS thread per connection (~24 threads instead of ~250 at 256
  connections). DB-route benchmarks gain +6% to +20% RPS at identical CPU
  per request; median latency improves while `db`/`queries` p99 grows by a
  few milliseconds from the extra netpoller wake hop. Forensics and paired
  A/B: `bench/reproducible/results/2026-06-12-wing-netpoll-takeover-evidence.md`.

### Fixed
- `c.Text` responses on Wing no longer share a global static cache: the Date
  header is always current, the background Date-patcher data race is gone,
  and dynamic text bodies no longer grow an unbounded cache.
- `c.HTML` now returns `ErrAlreadyResponded` on double-respond, matching
  `c.Text`/`c.JSON`.

## [1.2.5] — 2026-06-06

### Added
- Added reproducible Wing CPU, JSON, DB, resource, read-buffer, and pipelined syscall benchmark evidence after the v1.2.4 baseline.
- Added benchmark controls for default Kruda JSON encoder runs, DB dispatch sweeps, framework-specific DB DSNs, and pipelined syscall diagnostics.

### Changed
- Streamed Wing stdjson responses into pooled buffers and pre-sized JSON response buffers on the JSON response path.
- Preferred the Wing JSON responder for static JSON route hints.
- Clarified public benchmark wording, Wing query-profile guidance, and workload-specific read-only DB evidence without broadening CPU-bound handler-path claims.
- Documented `KRUDA_READ_BUF_SIZE=2048` as an optional short-header memory profile candidate while keeping the framework default unchanged.

### Fixed
- Skipped duplicate Wing accept re-arms on Linux epoll listeners after successful accept events, reducing accept hot-path churn without changing normal handler behavior.
- Stopped suggesting the nonexistent `WingStream` hint in public documentation.
- Normalized benchmark module local replace paths for current Go toolchain validation.

## [1.2.4] — 2026-05-28

### Added
- Added opt-in Wing static response route options for public static hot paths: `WingStaticText` and `WingStaticJSON`.
- Added reproducible CPU-bound benchmark evidence for Kruda, Fiber, and Actix, including latency percentiles, error counts, non-2xx counts, CPU/RAM resource data, syscall traces, and CPU profiles.
- Added Wing flight model documentation defining Transport, Wing, Feather, and Bone terminology.

### Changed
- Improved Wing CPU-bound handler paths with single-handler dispatch, inline JSON response writing, common-header parsing, route Feather caching, clean path caching, lazy peer address lookup, read buffer tuning, and lower fair-handler overhead.
- Updated public performance documentation to use balanced CPU-bound claim gates for throughput, p99 latency, socket errors, and non-2xx responses.
- Hardened the reproducible benchmark harness to run CPU-only routes for Kruda, Fiber, and Actix with warmups, multiple rounds, latency profiles, throughput profiles, raw logs, and summaries.

### Fixed
- Fixed static response cache keys to include status codes and avoid cross-status cache reuse.
- Preserved normal handler, middleware, lifecycle, cookie, CORS, and secure-header behavior outside explicitly documented static bypass routes.

## [1.2.3] — 2026-05-23

### Fixed
- Preserved response headers on fast response paths, including secure-header middleware output and net/http responses.
- Preserved overflow Wing headers so responses with more than the fixed inline header slots still serialize all configured headers.
- Preserved session cookie attributes when destroying sessions so deletion cookies keep the configured security policy.

### Changed
- Updated the documented Go patch baseline for currently supported secure toolchains.
- Tightened CI and benchmark reporting guardrails, including workflow timeouts, docs-only benchmark skips, standalone module coverage, and summarized benchmark output.

## [1.2.2] — 2026-05-20

### Fixed
- Replaced deprecated `reflect.Ptr` aliases with `reflect.Pointer` so the Linux Go 1.25.8 CI lint gate passes with current `golangci-lint`.

## [1.2.1] — 2026-05-19

### Fixed
- `App.Listen` now uses the full compile path, including lifecycle flag preparation and OpenAPI route registration.
- App-level DI containers now run `OnInit` before serving requests through `Listen`.
- `Ctx.Context()` now uses the underlying request context for net/http, test, and FastHTTP paths.
- FastHTTP direct serving now exposes `Ctx.Request()` and `Ctx.ResponseWriter()` for contrib middleware.
- Multipart parsing now enforces the configured body limit as a hard cap and maps oversized requests to HTTP 413.
- JWT HMAC signing and middleware reject empty secrets, and middleware enforces the configured algorithm.
- Session memory store now copies session data on save and get to avoid shared mutable map state.
- Cache default keys now include query parameters and hashed Authorization/Cookie headers to avoid cross-request leakage.

### Changed
- WebSocket defaults now set a 1 MiB max message size, 30 second fragmented message timeout, and 10 ping frames per second.
- `scripts/pre-release.sh` now tests standalone contrib modules, the Wing alias module, and the CLI module with temporary local replaces.

### Documentation
- Corrected API docs for `Use`, `Group`, DI lifecycle, health checks, resource route filters, HTTP/3 configuration, contrib README tables, and example metadata.
- Removed stale internal launch planning docs from public documentation.

## [1.2.0] — 2026-04-19

### Added
- Cross-transport integration smoke test exercising nethttp/fasthttp/wing end-to-end
- Native Go fuzz tests for router patterns + match (`FuzzRouterPattern`, `FuzzRouterMatch`), JSON binding (`FuzzBindJSON`), and validation (`FuzzValidateString`)
- Package-level `doc.go` overview for the core package and every contrib package — appears on pkg.go.dev
- Runnable `Example*` functions in godoc for the core API (`ExampleNew`, `ExamplePost`, `ExampleApp_Use`, `ExampleApp_Group`)
- `app_serve.go` — extracted request-dispatch internals from `kruda.go`
- `ctx_request.go`, `ctx_response.go`, `ctx_state.go`, `ctx_lifecycle.go` — split out from `context.go`
- Per-symbol godoc for previously undocumented exports: `Container`, `GoViewEngine.Render`, `WingConfig`, Wing Transport, semantic Feather presets, Wing stub Transport / DispatchMode constants
- `scripts/pre-release.sh` — gating validator (clean tree, no dev replace directives, all builds + tests + fuzz suites + godoc + examples)

### Changed
- Wing transport flattened into the core `kruda` package; `import "github.com/go-kruda/kruda/transport/wing"` continues to work as a deprecation alias.
- Test files renamed by feature for clarity (the previous `coverage_boost*_test.go` names — which were real tests with misleading names — became files like `error_constructors_test.go`, `context_methods_test.go`, etc.)
- Release process simplified to a single tag covering core + contrib — see [docs/release-process.md](docs/release-process.md). Old `scripts/tag-submodules.sh` removed.

### Deprecated
- `import "github.com/go-kruda/kruda/transport/wing"` — use `github.com/go-kruda/kruda` instead. The alias package continues to work and will be removed in v2.0.0.

### Fixed
- Eliminated the circular dependency between core and `transport/wing` that produced the broken v1.1.0–v1.1.2 releases (those tags are retracted in `go.mod`).
- **Wing fd-recycling race in `worker.cleanup()`** — pool, Spawn, and Takeover dispatch goroutines are now tracked via `sync.WaitGroup` (`pool.wg` for the pool, `worker.dispatchWG` for Spawn/Takeover). Cleanup waits for in-flight `RawSyscall(SYS_WRITE)` calls to finish before closing fds, preventing writes from landing on fds the kernel has already recycled to a new connection.
- **Wing shutdown deadlock with Takeover dispatch** — Takeover goroutines that block on `syscall.Read` are now unblocked by `syscall.Shutdown(fd, SHUT_RD)` before `dispatchWG.Wait()`. SHUT_RD returns EOF without freeing the fd number, so concurrent Spawn writes still target the right connection.
- **Wing shutdown `doneCh` saturation deadlock** — a drain goroutine consumes `doneCh` while `dispatchWG.Wait()` runs, preventing a wave of completing Spawn/Takeover goroutines from blocking their channel sends and never reaching `Done()`.
- **`ServeKruda` lifecycle now mirrors `ServeHTTP`** — `OnRequest` hook errors `goto response` (was `return`) so `OnResponse` hooks always fire for metrics/logging consistency. All hook iterations gated by `if app.hasLifecycle { … }` for zero-cost when no hooks are registered.
- WebSocket `dialWS` test helper preserves bytes the bufio.Reader greedily read past the handshake response, fixing a flaky `TestConn_ConcurrentWrites` (visible on macOS CI runners).

## [1.0.0] - 2026-03-07

### Added
- Wing transport — custom epoll+eventfd engine (default on Linux)
- eventfd wake mechanism replacing pipe on Linux (lower syscall overhead)
- Feather dispatch system — per-route I/O strategy hints (`WingPlaintext`, `WingJSON`, `WingQuery`, `WingRender`)
- `Ctx.SetBody([]byte) *Ctx` — lazy-send response body (zero-copy, chainable)
- `Ctx.SendBytes([]byte) error` — eager-send response body (immediate flush, terminal)
- `Ctx.SendBytesWithTypeBytes([]byte, []byte) error` — zero-alloc typed response
- `Ctx.SendStaticWithTypeBytes([]byte, []byte) error` — zero-copy for immutable data
- `Ctx.SetContentType(string) *Ctx` — set Content-Type header (chainable)
- sendfile(2) zero-copy support for Wing static file serving
- Wing RawRequest interface with Fd, RawHeader, RawBody, KeepAlive
- Wing MultipartForm support
- Wing read/write/idle timeouts + request Context cancellation
- TechEmpower Framework Benchmarks submission (`frameworks/Go/kruda/`)
- HTTP parser fuzz testing with seed corpus
- contrib/jwt — JWT authentication (HS256/384/512, RS256)
- contrib/ws — WebSocket with RFC 6455 compliance, ping rate limiting
- contrib/ratelimit — token bucket + sliding window rate limiting
- Security hardening: path traversal (3-layer), header injection, ReDoS prevention, SSE injection
- `SECURITY.md` with responsible disclosure policy (48h ack, 7d assessment, 90d disclosure)
- Consolidated security guide at `docs/guide/security.md`
- GC tuning documentation with GOGC/GOMEMLIMIT presets

### Changed
- Default transport: Wing on Linux, fasthttp on macOS, net/http on Windows (auto-fallback)
- TLS auto-fallback: Wing/fasthttp → net/http when TLS is configured
- Security headers defaults: X-Frame-Options DENY, X-XSS-Protection 0, Referrer-Policy strict-origin
- HTML escape in fortunes uses `&#34;` for quotes (TFB spec compliance)

### Removed
- Turbo/prefork mode (replaced by Wing transport)
- Legacy TFB code (`cmd/techempower/`, `techempower/`, root `Dockerfile.techempower`)
- Bone configuration axis (simplified to Feather presets)

### Performance
- Plaintext: 846K req/s (vs Fiber 670K, +26%; vs Actix 814K, +4%)
- JSON: 805K req/s (vs Fiber 625K, +29%; vs Actix 790K, +2%)
- DB: 108K req/s (vs Fiber 107K, +1%; vs Actix 37K, +190%)
- Fortunes: 104K req/s (vs Actix 45K, +131%)
- eventfd wake: +18% plaintext throughput vs pipe

## [0.5.0] — Phase 5: Production Ready

### Added
- Dev mode error page with source code context, stack trace, request details
- CLI tool `cmd/kruda/` with `new`, `dev`, `generate`, `validate` commands
- Hot reload dev server with 100ms file polling
- 21 runnable example applications
- GitHub Actions CI/CD: test matrix, benchmark regression, docs deployment
- VitePress documentation site in `docs/`
- Benchmark baseline (`bench/baseline.txt`)
- Cross-runtime benchmark suite (Go frameworks comparison)
- fasthttp transport for maximum throughput
- Integration tests (`integration_test.go`)
- Coverage gap tests reaching 92%+ on core package

### Security
- Default security headers: X-Content-Type-Options, X-Frame-Options, Referrer-Policy
- CRLF header injection prevention in SetHeader/AddHeader
- Request body size limit (4MB default) with 413 response
- CORS credentials + wildcard validation (panic at init)

## [0.4.0] — Phase 4: Ecosystem

### Added
- DI container with `Give`, `Use`, `GiveNamed`, `UseNamed`, `GiveLazy`, `GiveTransient`
- `MustUse`, `MustUseNamed` panic variants for DI resolution
- Module system with `Install(container)` interface
- Auto CRUD via `Resource(app, path, service)` with `ResourceService[T]` interface
- Resource options: `WithResourceOnly`, `WithResourceMiddleware`, `WithResourceIDParam`
- Health check endpoint with auto-discovery of `HealthChecker` services
- Error mapping: `MapError`, `MapErrorType[T]`, `MapErrorFunc`
- Test client `NewTestClient(app)` with fluent request builder
- `Resolve`, `ResolveNamed`, `MustResolve`, `MustResolveNamed` for handler-scoped DI
- Container lifecycle: `Start(ctx)`, `Shutdown(ctx)` for managed services

## [0.3.0] — Phase 3: Performance

### Added
- fasthttp transport for maximum throughput (default on macOS; Wing is default on Linux)
- `FastHTTP()` and `NetHTTP()` transport options
- Transport auto-fallback: TLS or Windows → net/http
- `WithTransport(transport.Transport)` for custom transport implementations
- HTTP/2 support via net/http TLS
- HTTP/3 (QUIC) config with `WithHTTP3(cert, key)` and Alt-Svc header
- Benchmark suite in `bench/` comparing Kruda, Gin, Fiber, Echo

## [0.2.0] — Phase 2: Type System & Validation

### Added
- Generic typed handlers `C[T]` with `Get/Post/Put/Delete/Patch[In, Out]`
- Short handlers `GetX/PostX/PutX/DeleteX/PatchX` (no error return)
- Group typed handlers `GroupGet/GroupPost/GroupPut/GroupDelete/GroupPatch`
- Input binding from param, query, body via struct tags
- Validation engine with `required`, `min`, `max`, `email`, `oneof` rules
- Custom validator registration via `app.Validator().Register()`
- JSON engine abstraction with Sonic + stdlib fallback (`json/`)
- `WithJSONEncoder`, `WithJSONDecoder` config options
- File upload support with `*FileUpload` struct binding
- SSE helper `c.SSE(callback)` with auto headers
- Route options `WithDescription`, `WithTags` for OpenAPI metadata

## [0.1.0] — Phase 1: Foundation

### Added
- `App` struct with `New()`, `Listen()`, graceful shutdown (SIGINT/SIGTERM)
- Radix tree router with static, `:param`, `*wildcard`, `:id<regex>`, `:id?` patterns
- AOT route compilation via `Compile()`
- `Ctx` struct with sync.Pool reuse, request/response API, method chaining
- Route groups with `Group(prefix)`, scoped middleware, `Done()`
- Middleware chain pre-built at registration time (zero-alloc hot path)
- Lifecycle hooks: OnRequest, BeforeHandle, AfterHandle, OnResponse, OnError, OnShutdown
- Config with functional options: `WithReadTimeout`, `WithWriteTimeout`, `WithIdleTimeout`, etc.
- Environment config via `WithEnvPrefix("APP")`
- Built-in middleware: Logger, Recovery, CORS, RequestID, Timeout
- `Map` type alias (`map[string]any`)
- `KrudaError` with convenience constructors (BadRequest, NotFound, InternalError, etc.)
- Transport interface with net/http implementation
- `internal/bytesconv` zero-copy byte/string conversion
- Hello world example (`examples/hello/`)
- MIT License

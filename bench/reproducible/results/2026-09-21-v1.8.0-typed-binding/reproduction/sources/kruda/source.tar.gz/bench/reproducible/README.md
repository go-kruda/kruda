# Benchmark Reproduction

This directory contains the source code and harness for Kruda, Fiber, and Actix CPU-bound benchmark comparisons.

The default benchmark does not require PostgreSQL. It measures framework overhead for high-performance, low-latency, high-throughput CPU-bound routes and records throughput, latency percentiles, socket errors, and non-2xx responses.

## Default Routes

| Route | Workload |
|------|----------|
| `/plaintext-handler` | Normal handler path returning plaintext |
| `/json-static` | Normal handler path returning constant JSON bytes, no serialization |
| `/json-serialize` | Normal handler path performing real JSON serialization |

DB, queries, fortunes, and updates are out of scope for the default comparison. Enable them explicitly with `BENCH_ENABLE_DB=1` when you want to study database-heavy workloads.

## Realistic API Route

`/realworld-profile/:id` is an opt-in realistic API route for checking whether
the frameworks still hold up after common production work is added: route
params, query validation, an auth gate, request-id header handling, one
PostgreSQL read, and a nested JSON response envelope. It intentionally reuses
the TechEmpower `world` table so the benchmark does not need a custom schema.

This is not a TechEmpower route and should be claimed separately from the
CPU-only and DB-only results.

```bash
BENCH_ENABLE_DB=1 ./bench.sh 'realworld-profile/42?include=summary&limit=3&token=benchmark-token'
```

## v1.2.6 Candidate Boundary

The post-v1.2.5 evidence does not support a broad CPU-bound +20% Actix claim on
the default fair handler path. Treat read-only DB workloads, serialized JSON,
pipelined HTTP/1.1 diagnostics, and short-header read-buffer tuning as separate
candidate tracks. Do not mix their results into one public performance claim.

## Directory Structure

```
bench/reproducible/
├── kruda/          # Kruda using Wing transport
├── fiber/          # Fiber v2 using fasthttp
├── actix/          # Actix Web 4
├── bench.sh        # Automated benchmark script
├── resource.sh     # CPU/RAM resource benchmark script
├── pipeline.sh     # HTTP/1.1 pipelined I/O diagnostic harness
├── pipeline-syscall.sh # Intrusive pipelined syscall-count diagnostic harness
├── sweep-kruda-cpu-dispatch.sh # Kruda-only CPU dispatch candidate sweep
├── pipeline-client/ # Go pipelined HTTP/1.1 load generator
├── profile-kruda.sh # Kruda-only pprof capture helper
└── README.md
```

## Prerequisites

```bash
go version
rustc --version
cargo --version
wrk --version
curl --version
```

The harness builds all three benchmark apps from their own directories.

The resource harness also requires `pidstat` from sysstat:

```bash
pidstat -V
```

## Run

```bash
cd bench/reproducible
./bench.sh
```

Run one route:

```bash
./bench.sh json-static
```

## Pipelined I/O Diagnostic

Use `pipeline.sh` when investigating whether an HTTP backend benefits from
batched writes and multiple in-flight HTTP/1.1 requests per TCP connection.
This is a diagnostic workload for I/O architecture decisions. Keep it separate
from the default `wrk --latency` handler-path benchmark claims because many
real clients do not use HTTP/1.1 pipelining.

```bash
cd bench/reproducible
./pipeline.sh plaintext-handler
```

The default profiles are:

| Profile | Connections | Pipeline depth |
|---------|------------:|---------------:|
| `baseline-c128-d1` | 128 | 1 |
| `pipeline-c128-d8` | 128 | 8 |
| `pipeline-c256-d8` | 256 | 8 |

Override profiles with `PIPELINE_PROFILES` entries in
`name:connections:depth` format:

```bash
PIPELINE_PROFILES="baseline-c128-d1:128:1 pipeline-c128-d16:128:16" ./pipeline.sh
```

The harness builds Kruda, Fiber, Actix, and `pipeline-client` from their own
directories, starts servers by PID, waits for readiness, and writes raw logs
plus `summary.csv`, `summary.md`, and `environment.txt` under
`results/pipeline-<timestamp>/`.

Use these results to decide whether to implement a workload-specific Wing I/O
profile or Preset. Do not use pipelined results as a blanket real-world API
claim unless the public wording labels the workload explicitly.

Use `pipeline-syscall.sh` when the question is specifically whether a
pipelined workload reduces write/send syscalls per request. It attaches
`strace -f -c` to the server, so the RPS and latency values are intrusive
diagnostic data. Use the syscall counts and `requests_per_write_send` ratio,
not the straced RPS, for I/O architecture decisions:

```bash
PROFILE_SUDO=1 BENCH_FRAMEWORKS="kruda actix" ./pipeline-syscall.sh plaintext-handler
```

For a depth-8 pipelined workload, a `requests_per_write_send` value near 8
means responses are being coalesced close to one write/send syscall per
client-side pipeline batch. A value near 1 means the server is still paying
roughly one write/send syscall per response.

## Kruda JSON Encoder Mode

The harness builds Kruda with `KRUDA_GO_TAGS=kruda_stdjson` by default so that
CPU-bound evidence measures the same encoder everywhere. For JSON handler
profile investigation, set `KRUDA_GO_TAGS=default` or an empty `KRUDA_GO_TAGS`
value to build Kruda without explicit Go build tags, which selects Sonic.

CGO does not enter into it: Sonic is pure Go plus assembly. (Before v1.7.0 a
`CGO_ENABLED=0` build silently got `encoding/json`, which is why older notes here
tied the engine to CGO availability.)

Compare the JSON serialization route with stdlib JSON:

```bash
KRUDA_GO_TAGS=kruda_stdjson RESULT_DIR=results/json-stdjson-$(date -u +%Y%m%dT%H%M%SZ) ./bench.sh json-serialize
```

Compare the same route with Kruda's default build tags:

```bash
KRUDA_GO_TAGS=default RESULT_DIR=results/json-default-$(date -u +%Y%m%dT%H%M%SZ) ./bench.sh json-serialize
```

For Kruda-only harness checks or dispatch sweeps, keep the default cross-runtime
behavior unchanged and set `BENCH_FRAMEWORKS` explicitly:

```bash
BENCH_FRAMEWORKS=kruda ./bench.sh json-serialize
```

Use the same `KRUDA_GO_TAGS` values with `resource.sh`, `profile-kruda.sh`, or
`syscall-profile.sh` when a JSON profile candidate needs resource or diagnostic
evidence. The generated `environment.txt` records the effective
`kruda_go_tags` value for each run.

Run opt-in DB routes:

```bash
BENCH_ENABLE_DB=1 ./bench.sh db fortunes
```

The DB mode expects a TechEmpower-style PostgreSQL database and uses `DATABASE_URL` when set.
When `DATABASE_URL` is not set, the cross-runtime harness uses framework-safe
defaults: Kruda and Fiber receive a pgx DSN with pool query parameters, while
Actix receives the same base PostgreSQL DSN without pgx-only query options.
Set `KRUDA_DATABASE_URL`, `FIBER_DATABASE_URL`, or `ACTIX_DATABASE_URL` for
framework-specific overrides. Set `BENCH_DATABASE_BASE_URL` to change the shared
default base DSN without disabling those framework-specific defaults.
Set `BENCH_ACTIX_WORKERS` only for methodology controls that intentionally pin
Actix's worker count. Leave it unset for the default Actix runtime behavior.
The harness records the effective `actix_workers` value in `environment.txt`.

For Kruda-only DB dispatch experiments, set `BENCH_KRUDA_DB_DISPATCH` to
`takeover`, `pool`, `spawn`, or `inline`. This affects only the Kruda
benchmark app and is meant for workload-profile evidence, not CPU-bound public
benchmark claims. Pool dispatch also requires explicit `KRUDA_POOL_SIZE`
evidence because the default pool size follows the Wing worker count:

```bash
BENCH_ENABLE_DB=1 BENCH_KRUDA_DB_DISPATCH=pool KRUDA_POOL_SIZE=64 ./bench.sh db queries fortunes updates
```

For repeatable Kruda-only DB dispatch sweeps, use:

```bash
./sweep-kruda-db-dispatch.sh db queries fortunes updates
```

The sweep runs Kruda only, stores per-run `bench.sh` output under
`results/kruda-db-dispatch-sweep-<timestamp>/runs/`, and writes aggregate
median RPS/p99/error summaries to `dispatch-summary.csv`, `summary.md`, and an
`environment.txt` with Git commit/dirty state plus sweep settings.

For Kruda-only CPU-bound dispatch experiments, set `BENCH_KRUDA_CPU_DISPATCH`
to `inline`, `takeover`, `pool`, or `spawn`. The default is `inline`, matching
the normal CPU-bound benchmark routes. This setting affects only the Kruda
benchmark app and is candidate-discovery tooling, not cross-runtime benchmark
claim evidence:

```bash
BENCH_FRAMEWORKS=kruda BENCH_KRUDA_CPU_DISPATCH=takeover ./bench.sh json-serialize
./sweep-kruda-cpu-dispatch.sh plaintext-handler json-static json-serialize
```

Current tiger evidence in
`results/2026-06-07-cpu-dispatch-sweep-evidence.md` rejects CPU-bound dispatch
mode changes as the next broad fair-handler performance path.

Current Phase 6 tiger sweep evidence is in
`results/phase6-profile-inventory-pr79-20260602T031308Z/`. In that run,
Takeover/Spear was the best throughput fit for `/db`, `/queries`, and
`/fortunes` with zero socket errors and zero non-2xx responses. The write-heavy
`/updates` route did not have a clean universal winner: Takeover/Spear kept
errors at zero but had high p99 latency, while Inline produced socket errors in
the throughput profile. Use this evidence as query-profile guidance, not as a
cross-runtime benchmark claim or a blanket recommendation for every DB write
route.

Kruda's benchmark pprof server is excluded from the default CPU-only benchmark binary so the runtime comparison does not include a diagnostic HTTP server that the Fiber and Actix apps do not run. The harness adds the `bench_pprof` Go build tag only when `BENCH_ENABLE_PPROF=1`:

```bash
BENCH_ENABLE_PPROF=1 ./bench.sh json-serialize
```

For Kruda-only candidate discovery, use `profile-kruda.sh` instead of the cross-runtime benchmark harness. It builds Kruda with `bench_pprof`, runs only CPU-bound Kruda routes, drives `wrk --latency`, captures Go CPU profiles, and writes `go tool pprof -top` reports under `results/profile-<timestamp>/`:

```bash
./profile-kruda.sh
./profile-kruda.sh json-serialize
BENCH_ENABLE_DB=1 BENCH_KRUDA_DB_DISPATCH=pool KRUDA_POOL_SIZE=64 ./profile-kruda.sh db
```

These profiles are diagnostic evidence for choosing the next candidate. They are not cross-runtime benchmark claim evidence because the pprof server and profiler overhead are enabled only for Kruda.

## Profiles

The script runs both profiles for every framework and route:

| Profile | wrk command shape |
|---------|-------------------|
| `latency` | `wrk --latency -t4 -c128 -d15s` |
| `throughput` | `wrk --latency -t4 -c256 -d15s` |

The harness sets `GOMAXPROCS=8` and `KRUDA_WORKERS=4` by default. The Kruda worker count matches the `wrk -t4` CPU-bound profiles and is recorded in every `environment.txt`. Override `KRUDA_WORKERS` explicitly when studying worker scaling.

Memory footprint experiments may set `KRUDA_READ_BUF_SIZE`, for example
`KRUDA_READ_BUF_SIZE=4096` for the current balanced benchmark profile or
`KRUDA_READ_BUF_SIZE=2048` for a more aggressive short-header memory candidate.
This is not the framework default and must be labeled as a workload-specific
memory profile; smaller buffers can reject requests whose request line and
headers do not fit the configured size.

Each framework/route/profile combination gets one warmup run and five measured rounds.

## Resource Run

Use `resource.sh` when the evidence needs CPU and RAM in addition to throughput and tail latency:

```bash
cd bench/reproducible
./resource.sh
```

Run one route:

```bash
./resource.sh json-serialize
```

The resource harness uses the same route and profile defaults as `bench.sh`. Each framework/route/profile combination gets one warmup run and one measured run while `pidstat` records process CPU, RSS, and context switch rates. CPU percentage is process CPU across cores, so `400%` means roughly four busy cores. The default `RESOURCE_MIN_CPU_SAMPLE=50` excludes low-CPU startup/shutdown tail samples from average CPU; set it to `0` to include every sample.

Use `BENCH_ENABLE_PPROF=1` with `resource.sh` only when the experiment intentionally measures profiling overhead.

## Output

Results are written to `bench/reproducible/results/<timestamp>/`:

| File | Purpose |
|------|---------|
| `environment.txt` | Git commit/dirty state, CPU, OS, toolchain, route, profile, and worker metadata |
| `summary.csv` | Machine-readable per-round RPS, p50, p90, p99, max latency, socket errors, and non-2xx responses |
| `summary.md` | Markdown table for PR evidence |
| `raw/*.txt` | Raw `wrk --latency` output and server logs |

Pipelined diagnostic results are written to
`bench/reproducible/results/pipeline-<timestamp>/`:

| File | Purpose |
|------|---------|
| `environment.txt` | Git commit/dirty state, CPU, OS, toolchain, route, profile, worker, and pipeline metadata |
| `summary.csv` | Machine-readable per-round requests, RPS, p50, p90, p99, max latency, socket errors, and non-2xx responses |
| `summary.md` | Markdown table for diagnostic evidence |
| `raw/*.txt` | Raw `pipeline-client` output and server logs |

Non-pipelined syscall diagnostic results are written to
`bench/reproducible/results/syscall-<timestamp>/`:

| File | Purpose |
|------|---------|
| `environment.txt` | Git commit/dirty state, CPU, OS, toolchain, route, worker, perf, and strace metadata |
| `summary.csv` | Machine-readable requests, latency, socket errors, perf counters, syscall counts, requests-per-syscall ratios, and per-1k-request syscall ratios |
| `summary.md` | Markdown table for diagnostic CPU and I/O evidence |
| `raw/*.txt` | Raw `wrk --latency`, `perf stat`, `strace -c`, server, attach, and status logs |

Pipelined syscall diagnostic results are written to
`bench/reproducible/results/pipeline-syscall-<timestamp>/`:

| File | Purpose |
|------|---------|
| `environment.txt` | Git commit/dirty state, CPU, OS, toolchain, route, profile, worker, pipeline, and strace metadata |
| `summary.csv` | Machine-readable requests, latency, socket errors, syscall counts, and requests-per-syscall ratios |
| `summary.md` | Markdown table for diagnostic I/O evidence |
| `raw/*.txt` | Raw `pipeline-client`, `strace -c`, server, attach, and status logs |

Resource results are written to `bench/reproducible/results/resource-<timestamp>/`:

| File | Purpose |
|------|---------|
| `environment.txt` | Git commit/dirty state, CPU, memory, OS, toolchain, route, profile, worker, and `pidstat` metadata |
| `resource-summary.csv` | Machine-readable wrk and pidstat output, including CPU, RSS, context switches, and RPS/core |
| `resource-aggregated.csv` | Smaller table for cross-framework comparison |
| `summary.md` | Markdown table for PR evidence |
| `raw/*.txt` | Raw `wrk --latency`, `pidstat`, and server logs |

## Claim Rule

Use "faster than Actix" only when Kruda median RPS is at least 3% higher than Actix and p99 is no worse than 10% above Actix with zero socket errors and zero non-2xx responses.

When those conditions are not met, use "same ballpark as Actix." Do not make RPS-only claims.

## Current Evidence

A post-v1.2.5 CPU-bound tiger follow-up on `perf/wing-nonpipelined-io-profile`
is in `results/2026-06-04-clean-cross-runtime-evidence.md` and
`results/2026-06-04-clean-resource-evidence.md`. It uses the normal CPU-bound
handler routes, `GOMAXPROCS=8`, `KRUDA_WORKERS=4`, and
`KRUDA_READ_BUF_SIZE=4096`. The run satisfied the "faster than Actix" gate on
all measured route/profile rows with zero socket errors and zero non-2xx
responses. Treat it as CPU-bound follow-up evidence, separate from the v1.2.6
DB, pipelined HTTP/1.1, and read-buffer candidate tracks below. The resource
evidence shows Kruda with higher RPS/core than Actix while Actix still uses less
RSS.

The committed tiger evidence captured at commit `984f0d6` satisfies the "faster than Actix" gate for CPU-bound Wing handler routes under both the latency and throughput profiles. Throughput-profile medians:

| Route | Evidence directory | Kruda vs Actix median RPS | Kruda vs Actix p99 |
|------|--------------------|---------------------------:|-------------------:|
| `/plaintext-handler` | `results/main-984f0d6-20260524T171346Z/` | +12.11% | -77.06% |
| `/json-static` | `results/main-984f0d6-20260524T171346Z/` | +13.50% | -74.24% |
| `/json-serialize` | `results/main-984f0d6-20260524T171346Z/` | +12.89% | -72.87% |

These are normal handler-path routes. Static bypass route options are intentionally separate from fair handler-path benchmark claims.

The corresponding resource evidence is in `results/resource-main-984f0d6-20260524T174429Z/`, with a summary note in `results/2026-05-25-main-984f0d6-tiger-evidence.md`. It uses `GOMAXPROCS=8`, `KRUDA_WORKERS=4`, and a default Kruda benchmark binary without the `bench_pprof` build tag to match the harness `wrk -t4` CPU-bound profiles. The run shows zero socket errors and zero non-2xx responses, with Kruda throughput, p99, and RPS/core ahead of Actix while RSS remains higher than Actix.

The accepted v1.2.6 read-only DB revalidation is in
`results/2026-06-06-v126-db-evidence.md`. It uses `BENCH_ENABLE_DB=1`,
`BENCH_KRUDA_DB_DISPATCH=takeover`, Kruda and Actix only, framework-specific
default DB DSNs, three measured rounds, 8s measured duration, and 2s warmup.
Throughput-profile medians were +166.13% versus Actix for `/db` and +92.47%
for `/fortunes`, with materially lower p99 latency and zero socket errors and
zero non-2xx responses. Keep this scoped to read-only DB workloads; do not mix
it into CPU-bound fair handler-path claims.

The corrected Actix `/queries` route evidence is in
`results/2026-06-07-actix-queries-db-extended-evidence.md`, and the
Fiber-inclusive read-only DB run from `main` commit `b84e19b` is in
`results/2026-06-11-fiber-db-read-evidence.md`. The Fiber-inclusive run
reproduces the scoped `/db`, `/queries`, and `/fortunes` wins versus Actix and
shows the scoped DB story does not extend to Fiber: Kruda median RPS was
0.41-10.84% below Fiber on those routes, with lower median p99 than Fiber on
`/db` and `/queries` but not `/fortunes`. Use "same ballpark as Fiber" for
read-only DB RPS wording.

The v1.2.6 HTTP/1.1 pipelined diagnostic recheck is in
`results/2026-06-07-v126-pipeline-evidence.md`. It uses `pipeline.sh` with
Kruda and Actix, three rounds, 5s measured duration, 2s warmup, and profiles
`baseline-c128-d1`, `pipeline-c128-d8`, and `pipeline-c256-d8`. Kruda had higher
median RPS and lower p99 than Actix in all nine profile/route rows with zero
socket errors and zero non-2xx responses. Keep this labeled as pipelined
HTTP/1.1 diagnostic evidence; do not mix it into default fair handler-path
claims.

The optional short-header read-buffer resource profile is in `results/resource-20260524Tphase7-readbuf4k/`, with a summary note in `results/2026-05-24-read-buffer-size-evidence.md`. It uses `KRUDA_READ_BUF_SIZE=4096`; compared with the phase 6 baseline, Kruda max RSS dropped by 10.77%, 17.61%, and 10.85% on the throughput routes. Actix still has lower RSS, so this is RSS reduction evidence, not a memory-footprint win claim.

The repeated `KRUDA_READ_BUF_SIZE=2048` resource candidate is documented in
`results/2026-06-04-read-buffer-2048-evidence.md` and rechecked in
`results/2026-06-07-v126-readbuf2048-evidence.md`. The v1.2.6 recheck reduced
Kruda max RSS by 4.64-9.84% versus a same-runner `4096` baseline while
preserving zero socket errors and zero non-2xx responses. It did not pass the
strict default-change gate because p99 regressed on every measured
route/profile row and RPS fell by 0.68-4.37%, so keep `4096` as the balanced
throughput/p99 evidence profile and treat `2048` as an optional short-header
memory profile candidate.

The lazy Wing peer-address lookup evidence is in `results/resource-20260524Tphase8-lazy-remote-addr-final-readbuf4k/`, with a summary note in `results/2026-05-24-lazy-remote-addr-evidence.md`. It shows the same CPU-bound handler routes with zero socket errors and zero non-2xx responses, and a short `strace` check confirms that routes which do not call `RemoteAddr()` no longer pay eager `getpeername` syscalls on accept.

package main

import (
	"context"
	"fmt"
	"math/rand/v2"
	"os"
	"sort"
	"strconv"
	"strings"
	"sync"

	"github.com/go-kruda/kruda"
	"github.com/go-kruda/kruda/contrib/observability"
	krudajson "github.com/go-kruda/kruda/json"
	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgxpool"
)

// TFB types
type World struct {
	ID           int32 `json:"id"`
	RandomNumber int32 `json:"randomNumber"`
}

type Fortune struct {
	ID      int32
	Message string
}

type JSONMessage struct {
	Message string `json:"message"`
}

var (
	staticJSONBody = []byte(`{"message":"Hello, World!"}`)
)

// bench types
type JSONBody struct {
	Name  string  `json:"name"`
	Value float64 `json:"value"`
}

type JSONResponse struct {
	Message string   `json:"message"`
	Data    JSONBody `json:"data"`
}

type UserResponse struct {
	ID    int    `json:"id"`
	Name  string `json:"name"`
	Email string `json:"email"`
}

type RealworldProfileResponse struct {
	RequestID string                  `json:"requestId"`
	Profile   RealworldProfile        `json:"profile"`
	Summary   RealworldProfileSummary `json:"summary"`
}

type RealworldProfile struct {
	ID           int32  `json:"id"`
	Name         string `json:"name"`
	Email        string `json:"email"`
	RandomNumber int32  `json:"randomNumber"`
	Include      string `json:"include"`
}

type RealworldProfileSummary struct {
	Limit     int      `json:"limit"`
	Features  []string `json:"features"`
	TraceMode string   `json:"traceMode"`
}

var pool *pgxpool.Pool

func main() {
	port := os.Getenv("PORT")
	if port == "" {
		port = "3000"
	}
	dsn := os.Getenv("DATABASE_URL")
	if dsn == "" {
		dsn = "postgres://benchmarkdbuser:benchmarkdbpass@localhost:5433/hello_world?pool_max_conns=64&pool_min_conns=8"
	}

	// ActiveEngine, not EncoderName: this line labels the evidence a run
	// produces, and the tag can name sonic on a build where sonic has fallen
	// back to encoding/json.
	fmt.Printf("[kruda] JSON encoder: %s\n", krudajson.ActiveEngine())

	cpuDispatchMode, err := normalizeBenchDispatch(os.Getenv("BENCH_KRUDA_CPU_DISPATCH"), "inline")
	if err != nil {
		fmt.Fprintf(os.Stderr, "BENCH_KRUDA_CPU_DISPATCH: %v\n", err)
		os.Exit(1)
	}
	if os.Getenv("BENCH_KRUDA_CPU_DISPATCH") != "" {
		fmt.Printf("[kruda] CPU dispatch: %s\n", cpuDispatchMode)
	}

	enableDB := os.Getenv("BENCH_ENABLE_DB") == "1"
	dbDispatchMode := "takeover"
	if enableDB {
		dbDispatchMode, err = normalizeBenchDispatch(os.Getenv("BENCH_KRUDA_DB_DISPATCH"), "takeover")
		if err != nil {
			fmt.Fprintf(os.Stderr, "BENCH_KRUDA_DB_DISPATCH: %v\n", err)
			os.Exit(1)
		}
		fmt.Printf("[kruda] DB dispatch: %s\n", dbDispatchMode)
		cfg, _ := pgxpool.ParseConfig(dsn)
		cfg.AfterConnect = func(ctx context.Context, conn *pgx.Conn) error {
			conn.Prepare(ctx, "worldSelect", "SELECT randomnumber FROM world WHERE id=$1")
			conn.Prepare(ctx, "fortuneSelect", "SELECT id, message FROM fortune")
			conn.Prepare(ctx, "worldUpdate", "UPDATE world SET randomnumber=$1 WHERE id=$2")
			return nil
		}
		pool, err = pgxpool.NewWithConfig(context.Background(), cfg)
		if err != nil {
			fmt.Fprintf(os.Stderr, "pgxpool: %v\n", err)
			os.Exit(1)
		}
	}

	startPprof()

	app := kruda.New(kruda.Wing())

	// Opt-in observability for the D3 enabled-path A/B. Enable MUST run before any
	// route so the span middleware bakes into every route chain. Run the baseline
	// arm with BENCH_ENABLE_OBS unset; the enabled arm with BENCH_ENABLE_OBS=1
	// (typically OTEL_TRACES_EXPORTER=none so no collector is required — the span
	// is still created and the RED-metrics OnResponse hook still fires, which
	// drops the Wing fast lane, so the per-request hot-path cost is measured).
	if os.Getenv("BENCH_ENABLE_OBS") == "1" {
		traces := os.Getenv("BENCH_OBS_TRACES") != "0" // =0 isolates the RED-metrics cost
		obsCfg := observability.Config{ServiceName: "bench-kruda"}
		if !traces {
			obsCfg.TracesEnabled = &traces
		}
		if _, err := observability.Enable(app, obsCfg); err != nil {
			fmt.Fprintf(os.Stderr, "observability.Enable: %v\n", err)
			os.Exit(1)
		}
		fmt.Printf("[kruda] observability: ENABLED (traces=%v)\n", traces)
	}

	plaintext := func(c *kruda.Ctx) error {
		return c.Text("Hello, World!")
	}
	app.Get("/", plaintext, cpuRouteOptions(cpuDispatchMode, kruda.Plaintext)...)
	app.Get("/plaintext-handler", plaintext, cpuRouteOptions(cpuDispatchMode, kruda.Plaintext)...)

	app.Get("/json-static", func(c *kruda.Ctx) error {
		return c.SendStaticJSON(staticJSONBody)
	}, cpuRouteOptions(cpuDispatchMode, kruda.JSON)...)

	jsonSerialize := func(c *kruda.Ctx) error {
		return c.JSON(JSONMessage{Message: "Hello, World!"})
	}
	app.Get("/json", jsonSerialize, cpuRouteOptions(cpuDispatchMode, kruda.JSON)...)
	app.Get("/json-serialize", jsonSerialize, cpuRouteOptions(cpuDispatchMode, kruda.JSON)...)

	app.Get("/users/:id", func(c *kruda.Ctx) error {
		id, _ := c.ParamInt("id")
		return c.JSON(UserResponse{ID: id, Name: "Tiger", Email: "tiger@kruda.dev"})
	}, cpuRouteOptions(cpuDispatchMode, kruda.JSON)...)

	app.Post("/json", func(c *kruda.Ctx) error {
		var body JSONBody
		if err := c.Bind(&body); err != nil {
			return c.Status(400).JSON(map[string]string{"error": err.Error()})
		}
		return c.JSON(JSONResponse{Message: "received", Data: body})
	}, cpuRouteOptions(cpuDispatchMode, kruda.JSON)...)

	if enableDB {
		registerDBRoutes(app, dbDispatchMode)
		registerRealworldRoutes(app, dbDispatchMode)
	}

	if err := app.Listen(":" + port); err != nil {
		fmt.Fprintf(os.Stderr, "kruda listen: %v\n", err)
		os.Exit(1)
	}
}

func registerDBRoutes(app *kruda.App, dbDispatchMode string) {
	// TFB: single DB query
	app.Get("/db", func(c *kruda.Ctx) error {
		w := World{ID: int32(rand.IntN(10000) + 1)}
		pool.QueryRow(context.Background(), "worldSelect", w.ID).Scan(&w.RandomNumber)
		return c.JSON(w)
	}, dbRouteOptions(dbDispatchMode, kruda.DB)...)

	// TFB: multiple queries — pipeline via SendBatch. n==1 short-circuits to
	// a direct QueryRow (same as /db): batch pipeline setup/teardown costs
	// more than the one query it carries. The Fiber app applies the same
	// short-circuit so the cell stays a framework comparison.
	app.Get("/queries", func(c *kruda.Ctx) error {
		n := clamp(queryCount(c), 1, 500)
		if n == 1 {
			w := World{ID: int32(rand.IntN(10000) + 1)}
			pool.QueryRow(context.Background(), "worldSelect", w.ID).Scan(&w.RandomNumber)
			return c.JSON([]World{w})
		}
		worlds := make([]World, n)
		for i := range worlds {
			worlds[i].ID = int32(rand.IntN(10000) + 1)
		}
		batch := &pgx.Batch{}
		for i := range worlds {
			batch.Queue("worldSelect", worlds[i].ID)
		}
		br := pool.SendBatch(context.Background(), batch)
		for i := range worlds {
			br.QueryRow().Scan(&worlds[i].RandomNumber)
		}
		br.Close()
		return c.JSON(worlds)
	}, dbRouteOptions(dbDispatchMode, kruda.DB)...)

	// TFB: fortunes
	app.Get("/fortunes", func(c *kruda.Ctx) error {
		rows, err := pool.Query(context.Background(), "fortuneSelect")
		if err != nil {
			return c.Status(500).Text(err.Error())
		}
		defer rows.Close()

		fortunes := make([]Fortune, 0, 13)
		for rows.Next() {
			var f Fortune
			rows.Scan(&f.ID, &f.Message)
			fortunes = append(fortunes, f)
		}
		fortunes = append(fortunes, Fortune{Message: "Additional fortune added at request time."})
		sort.Slice(fortunes, func(i, j int) bool { return fortunes[i].Message < fortunes[j].Message })

		return c.HTML(fortunesHTML(fortunes))
	}, dbRouteOptions(dbDispatchMode, kruda.Render)...)

	// TFB: updates — batch SELECT + batch UPDATE
	app.Get("/updates", func(c *kruda.Ctx) error {
		n := clamp(queryCount(c), 1, 500)
		worlds := make([]World, n)
		for i := range worlds {
			worlds[i].ID = int32(rand.IntN(10000) + 1)
		}
		batch := &pgx.Batch{}
		for i := range worlds {
			batch.Queue("worldSelect", worlds[i].ID)
		}
		br := pool.SendBatch(context.Background(), batch)
		for i := range worlds {
			br.QueryRow().Scan(&worlds[i].RandomNumber)
			worlds[i].RandomNumber = int32(rand.IntN(10000) + 1)
		}
		br.Close()
		ids := make([]int32, n)
		nums := make([]int32, n)
		for i, w := range worlds {
			ids[i] = w.ID
			nums[i] = w.RandomNumber
		}
		pool.Exec(context.Background(),
			"UPDATE world SET randomnumber=v.r FROM (SELECT unnest($1::int[]) id, unnest($2::int[]) r) v WHERE world.id=v.id",
			ids, nums,
		)
		return c.JSON(worlds)
	}, dbRouteOptions(dbDispatchMode, kruda.DB)...)
}

func registerRealworldRoutes(app *kruda.App, dbDispatchMode string) {
	app.Get("/realworld-profile/:id", func(c *kruda.Ctx) error {
		if c.Query("token") != "benchmark-token" {
			return c.Status(401).JSON(map[string]string{"error": "unauthorized"})
		}

		id, err := c.ParamInt("id")
		if err != nil || id < 1 || id > 10000 {
			return c.Status(400).JSON(map[string]string{"error": "invalid profile id"})
		}

		include := c.Query("include", "summary")
		if include != "summary" && include != "detail" {
			return c.Status(400).JSON(map[string]string{"error": "invalid include"})
		}
		limit := clamp(c.QueryInt("limit", 3), 1, 20)

		requestID := c.Header("X-Request-Id")
		if requestID == "" {
			requestID = "bench-" + strconv.Itoa(id)
		}
		c.SetHeader("X-Request-Id", requestID)

		w := World{ID: int32(id)}
		if err := pool.QueryRow(context.Background(), "worldSelect", w.ID).Scan(&w.RandomNumber); err != nil {
			return c.Status(500).JSON(map[string]string{"error": err.Error()})
		}

		return c.JSON(RealworldProfileResponse{
			RequestID: requestID,
			Profile: RealworldProfile{
				ID:           w.ID,
				Name:         "Tiger Team",
				Email:        "tiger@kruda.dev",
				RandomNumber: w.RandomNumber,
				Include:      include,
			},
			Summary: RealworldProfileSummary{
				Limit:     limit,
				Features:  []string{"auth", "validation", "postgres", "json"},
				TraceMode: "request-id",
			},
		})
	}, dbRouteOptions(dbDispatchMode, kruda.DB)...)
}

func normalizeBenchDispatch(value string, defaultMode string) (string, error) {
	value = strings.TrimSpace(value)
	if value == "" {
		return defaultMode, nil
	}
	switch strings.ToLower(strings.TrimSpace(value)) {
	case "takeover", "spear":
		return "takeover", nil
	case "pool", "arrow":
		return "pool", nil
	case "spawn":
		return "spawn", nil
	case "inline", "bolt":
		return "inline", nil
	default:
		return "", fmt.Errorf("unknown mode %q; use takeover, pool, spawn, or inline", value)
	}
}

func cpuRouteOptions(mode string, base kruda.Preset) []kruda.RouteOption {
	switch mode {
	case "inline":
		base.Dispatch = kruda.Inline
	case "pool":
		base.Dispatch = kruda.Pool
	case "spawn":
		base.Dispatch = kruda.Spawn
	case "takeover":
		base.Dispatch = kruda.Takeover
	}
	return []kruda.RouteOption{base}
}

func dbRouteOptions(mode string, fallback kruda.RouteOption) []kruda.RouteOption {
	switch mode {
	case "takeover":
		return []kruda.RouteOption{fallback}
	case "pool":
		return []kruda.RouteOption{kruda.Arrow}
	case "spawn":
		return []kruda.RouteOption{kruda.Preset{Dispatch: kruda.Spawn}}
	case "inline":
		return []kruda.RouteOption{kruda.Bolt}
	default:
		return nil
	}
}

func queryCount(c *kruda.Ctx) int {
	n, _ := strconv.Atoi(c.Query("q"))
	return n
}

func clamp(n, lo, hi int) int {
	if n < lo {
		return lo
	}
	if n > hi {
		return hi
	}
	return n
}

var fortuneBufPool = sync.Pool{
	New: func() any { b := make([]byte, 0, 4096); return &b },
}

func fortunesHTML(ff []Fortune) string {
	bp := fortuneBufPool.Get().(*[]byte)
	buf := (*bp)[:0]
	buf = append(buf, "<!DOCTYPE html><html><head><title>Fortunes</title></head><body><table><tr><th>id</th><th>message</th></tr>"...)
	for _, f := range ff {
		buf = append(buf, "<tr><td>"...)
		buf = strconv.AppendInt(buf, int64(f.ID), 10)
		buf = append(buf, "</td><td>"...)
		buf = appendHTMLEscape(buf, f.Message)
		buf = append(buf, "</td></tr>"...)
	}
	buf = append(buf, "</table></body></html>"...)
	s := string(buf)
	*bp = buf
	fortuneBufPool.Put(bp)
	return s
}

func appendHTMLEscape(buf []byte, s string) []byte {
	last := 0
	for i := 0; i < len(s); i++ {
		var esc string
		switch s[i] {
		case '&':
			esc = "&amp;"
		case '<':
			esc = "&lt;"
		case '>':
			esc = "&gt;"
		case '"':
			esc = "&#34;"
		case '\'':
			esc = "&#39;"
		default:
			continue
		}
		buf = append(buf, s[last:i]...)
		buf = append(buf, esc...)
		last = i + 1
	}
	return append(buf, s[last:]...)
}
